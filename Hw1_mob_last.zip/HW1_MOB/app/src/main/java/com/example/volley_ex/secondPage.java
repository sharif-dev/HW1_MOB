package com.example.volley_ex;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
@SuppressLint("Registered")
public class secondPage extends AppCompatActivity {

    String[] week = {
            "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
    };


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        String wether_string = "";
        Button btn_back = findViewById(R.id.btn_back);
        TextView[] day, min_temp, max_temp;
        ImageView[] images;
        TextView city_name = findViewById(R.id.city_name_text);

        day = new TextView[7];
        min_temp = new TextView[7];
        max_temp = new TextView[7];

        min_temp[0] = findViewById(R.id.min_temp_1);
        min_temp[1] = findViewById(R.id.min_temp_2);
        min_temp[2] = findViewById(R.id.min_temp_3);
        min_temp[3] = findViewById(R.id.min_temp_4);
        min_temp[4] = findViewById(R.id.min_temp_5);
        min_temp[5] = findViewById(R.id.min_temp_6);
        min_temp[6] = findViewById(R.id.min_temp_7);

        max_temp[0] = findViewById(R.id.max_temp_1);
        max_temp[1] = findViewById(R.id.max_temp_2);
        max_temp[2] = findViewById(R.id.max_temp_3);
        max_temp[3] = findViewById(R.id.max_temp_4);
        max_temp[4] = findViewById(R.id.max_temp_5);
        max_temp[5] = findViewById(R.id.max_temp_6);
        max_temp[6] = findViewById(R.id.max_temp_7);

        day[0] = findViewById(R.id.day_1);
        day[1] = findViewById(R.id.day_2);
        day[2] = findViewById(R.id.day_3);
        day[3] = findViewById(R.id.day_4);
        day[4] = findViewById(R.id.day_5);
        day[5] = findViewById(R.id.day_6);
        day[6] = findViewById(R.id.day_7);

        images = new ImageView[7];
        images[0] = findViewById(R.id.image_1);
        images[1] = findViewById(R.id.image_2);
        images[2] = findViewById(R.id.image_3);
        images[3] = findViewById(R.id.image_4);
        images[4] = findViewById(R.id.image_5);
        images[5] = findViewById(R.id.image_6);
        images[6] = findViewById(R.id.image_7);



        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        Date d = new Date();
        String dayOfTheWeek = sdf.format(d);
        int index = 0;
        for (int k = 0; k < 7; k++) {
            if (dayOfTheWeek.equals(week[k])) {
                index = k;
                break;
            }
        }
        for (int k = 0; k < 7; k++) {
            day[k].setText(week[(index + k) % 7]);
        }


        if (bundle != null) {
            wether_string = (String) bundle.get(MainActivity.weather_id);
        }
        assert wether_string != null;
        String[] temperature = wether_string.split("_");
        char tmp = Character.toUpperCase(temperature[0].charAt(0));
        temperature[0] = tmp + temperature[0].substring(1);
        if ((temperature[0] + " ," + temperature[2]).length() < 15) {
            city_name.setText(temperature[0] + " ," + temperature[2]);
        }else {
            city_name.setText(temperature[0]);
        }

        int n = temperature.length;

        int counter = 0;

        for (int i = n - 21; i < n; i = i + 3) {
            max_temp[counter].setText(temperature[i] + " °c");
            min_temp[counter].setText(temperature[i + 1] + " °c");
            String temp = temperature[i + 2];
            if (temp.contains("rain")) {
                images[counter].setImageResource(R.drawable.rainy);
            } else if (temp.contains("snow")) {
                images[counter].setImageResource(R.drawable.snow);
            } else if (temp.contains("sun")) {
                if (temp.contains("cloud")) {
                    images[counter].setImageResource(R.drawable.cloud_sun);
                } else {
                    images[counter].setImageResource(R.drawable.sunny);
                }
            } else if (temp.contains("cloud")) {
                images[counter].setImageResource(R.drawable.cloudy);
            }
            counter++;
        }

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(secondPage.this, MainActivity.class);
                startActivity(intent);
            }
        });



    }



}
