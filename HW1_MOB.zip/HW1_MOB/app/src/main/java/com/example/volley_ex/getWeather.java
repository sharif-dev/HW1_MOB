package com.example.volley_ex;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class getWeather {

    private static final String TAG = "getWeather";

    public  void getWeatherstatus(final String longitude, final String latitude, final Context context, final Handler handler) {
        Thread thread = new Thread() {

            public void run() {
                String server_url="https://api.weatherapi.com/v1/forecast.json?q="+latitude+","+longitude+"&key=1dcc0a5f5df54b03863131439200104%20&days=7";
                RequestQueue requestQueue;
                requestQueue= Volley.newRequestQueue(context);
                {
                    JsonObjectRequest request=new JsonObjectRequest(Request.Method.GET, server_url, null, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                JSONObject location=response.getJSONObject("location");
                                String region=location.getString("region");
                                String country=location.getString("country");

                                JSONObject current_weather=response.getJSONObject("current");
                                String temp_c=current_weather.getString("temp_c");

                                JSONObject current_weather_condition=current_weather.getJSONObject("condition");

                                String text=current_weather_condition.getString("text");

                                JSONObject forecast=response.getJSONObject("forecast");

                                JSONArray forecastday=forecast.getJSONArray("forecastday");

                                String date[]=new String[7];
                                String maxtemp_c[]=new String[7];
                                String mintemp_c[]=new String[7];
                                String avgtemp_c[]=new String[7];
                                String text_status[]=new String[7];

                                for (int i = 0; i < forecastday.length(); i++) {

                                    JSONObject days  = forecastday.getJSONObject(i);
                                    date[i]=days.getString("date");
                                    JSONObject day=days.getJSONObject("day");
                                    JSONObject condition=day.getJSONObject("condition");
                                    text_status[i]=condition.getString("text");
                                    maxtemp_c[i]=day.getString("maxtemp_c");
                                    mintemp_c[i]=day.getString("mintemp_c");
                                    avgtemp_c[i]=day.getString("avgtemp_c");


                                }

                                Message message = Message.obtain();
                                message.setTarget(handler);
                                message.what = 1;
                                Bundle bundle = new Bundle();
                                String status=region+"_"+country+"_"+temp_c+"_"+text+"_"+maxtemp_c[0]+"_"+mintemp_c[0]+"_"+text_status[0]+"_"+maxtemp_c[1]+ "_"+mintemp_c[1]+"_"+text_status[1]+"_"+maxtemp_c[2]+"_"+mintemp_c[2]+"_"+text_status[2]+"_"+maxtemp_c[3]+"_"+mintemp_c[3]+"_"+text_status[3]+"_"+maxtemp_c[4]+ "_"+mintemp_c[4]+"_"+text_status[4]+"_"+maxtemp_c[5]+"_"+mintemp_c[5]+"_"+text_status[5]+"_"+maxtemp_c[6]+"_"+mintemp_c[6]+"_"+text_status[6];
                                bundle.putString("result",status);
                                message.setData(bundle);
                                message.sendToTarget();
                                Log.i(TAG, "response "+status+" "+android.os.Process.myTid());


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            error.printStackTrace();

                        }
                    });

                    requestQueue.add(request);




                }

            }
        };
        thread.start();
    }
}
