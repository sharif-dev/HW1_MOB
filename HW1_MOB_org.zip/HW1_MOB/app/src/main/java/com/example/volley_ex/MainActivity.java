package com.example.volley_ex;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {


    getWeather getWeather_ = new getWeather();
    Handler handler = new threadHandler1();
    String weather_status;
    ProgressBar waiting;
    static final String weather_id = "weather_id";
    String city = "";
    final static String TAG = MainActivity.class.getName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_page);
        Button btn_getLatAndLng = findViewById(R.id.nextpage);
        waiting = findViewById(R.id.progressBar);
        waiting.setVisibility(View.GONE);
        final EditText inp = findViewById(R.id.plain_text_input);
        ConnectivityManager cm = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);

        assert cm != null;
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        if (!isConnected) {
            Toast.makeText(getApplicationContext(), "Network is not connected!", Toast.LENGTH_SHORT).show();
            String weather_stat = readFromFile(MainActivity.this);
            Intent intent = new Intent(MainActivity.this, secondPage.class);
            intent.putExtra(weather_id, weather_stat);
            startActivity(intent);
            finish();
        } else
            btn_getLatAndLng.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    waiting.setVisibility(View.VISIBLE);
                    city = inp.getText().toString();
                    new LatitudeAndLongitude(city, getApplicationContext(), new threadHandler()).start();


                }
            });
    }

    @SuppressLint("HandlerLeak")
    private class threadHandler extends Handler {
        final ListView listview = findViewById(R.id.list_v);
        ArrayAdapter<String> adapter;

        @Override
        public void handleMessage(Message message) {
            String LatAndLng;
            if (message.what == 1) {
                LatAndLng = message.getData().getString("result");
            } else
                LatAndLng = null;

            assert LatAndLng != null;
            if (!LatAndLng.equals("not found")) {
                String[] LatAndLng_ = LatAndLng.split("\n", 0);
                int number_of_cities;
                number_of_cities = LatAndLng_.length;
                String[] CITIES = new String[number_of_cities];
                final String[][] coordinate = new String[number_of_cities][2];
                for (int i = 0; i < number_of_cities; i++) {
                    String[] tem = LatAndLng_[i].split(" ");
                    int n = tem.length;
                    coordinate[i][0] = (tem[n - 2]);
                    coordinate[i][1] = (tem[n - 1]);
                    CITIES[i] = tem[0];
                    for (int j = 1; j < n - 2; j++) {
                        CITIES[i] = CITIES[i] + tem[j];
                    }
                }
                adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, CITIES);
                waiting.setVisibility(View.GONE);
                listview.setAdapter(adapter);

                listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        waiting.setVisibility(View.VISIBLE);
                        getWeather_.getWeatherstatus(coordinate[position][0], coordinate[position][1], getApplicationContext(), handler);
                    }
                });
            } else {
                waiting.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "Not found!", Toast.LENGTH_SHORT).show();


            }
        }
    }

    @SuppressLint("HandlerLeak")
    private class threadHandler1 extends Handler {
        @Override
        public void handleMessage(Message message) {
            Bundle bundle = message.getData();
            weather_status = city + "_" + bundle.getString("result");
            writeToFile(weather_status, MainActivity.this);
            Intent intent = new Intent(MainActivity.this, secondPage.class);
            intent.putExtra(weather_id, weather_status);
            startActivity(intent);
            waiting.setVisibility(View.GONE);

        }
    }


    private String readFromFile(Context context) {

        String ret = "";

        try {
            InputStream inputStream = context.openFileInput("config.txt");

            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString;
                StringBuilder stringBuilder = new StringBuilder();

                while ((receiveString = bufferedReader.readLine()) != null) {
                    stringBuilder.append("").append(receiveString);
                }

                inputStream.close();
                ret = stringBuilder.toString();
            }
        } catch (FileNotFoundException e) {
            Log.e("login activity", "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e("login activity", "Can not read file: " + e.toString());
        }

        return ret;
    }

    private void writeToFile(String data, Context context) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("config.txt", Context.MODE_PRIVATE));
            outputStreamWriter.write(data);
            outputStreamWriter.close();
        } catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }


}
