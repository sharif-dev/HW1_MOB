package com.example.volley_ex;

class weather_data {
    private String day;
    private String date;
    private String min_temperture;
    private String max_temperture;
    private String condition;

    weather_data(String day, String date, String min_temperture,String max_temperture, String condition) {
        setDay(day);
        setDate(date);
        setCondition(condition);
        setMax_temperture(max_temperture);
        setMin_temperture(min_temperture);
    }

    private void setCondition(String condition) {
        this.condition = condition;
    }

    private void setDate(String date) {
        this.date = date;
    }

    private void setDay(String day) {
        this.day = day;
    }

    private void setMax_temperture(String max_temperture) {
        this.max_temperture = max_temperture;
    }

    private void setMin_temperture(String min_temperture) {
        this.min_temperture = min_temperture;
    }

    String getDate() {
        return date;
    }

    String getDay() {
        return day;
    }

    String getMax_temperture() {
        return max_temperture;
    }

    String getMin_temperture() {
        return min_temperture;
    }

    String getCondition() {
        return condition;
    }
}
