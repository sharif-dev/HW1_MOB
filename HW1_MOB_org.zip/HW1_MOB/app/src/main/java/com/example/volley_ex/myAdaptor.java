package com.example.volley_ex;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import static com.example.volley_ex.R.layout.day_item;

class myAdaptor extends RecyclerView.Adapter<myAdaptor.ViewHolder> {
    private ArrayList<com.example.volley_ex.weather_data> weather_data;
    private int index = 0;

    myAdaptor(ArrayList<com.example.volley_ex.weather_data> weather_data) {
        this.weather_data = weather_data;
    }

    @NonNull


    public myAdaptor.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(day_item, parent, false);
        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (index > 0)
            holder.day.setText(this.weather_data.get(index).getDay());
        else
            holder.day.setText("Today");
        holder.date.setText(this.weather_data.get(index).getDate());
        holder.min_temperature.setText(this.weather_data.get(index).getMin_temperture());
        holder.max_temperature.setText(this.weather_data.get(index).getMax_temperture());
        holder.weather_text.setText(this.weather_data.get(index).getCondition());

        if (this.weather_data.get(index).getCondition().contains("storm"))
            holder.weather_icon.setImageResource(R.drawable.storm);
        else if (this.weather_data.get(index).getCondition().contains("thunder"))
            holder.weather_icon.setImageResource(R.drawable.thunderbolt);
        else if (this.weather_data.get(index).getCondition().contains("snow"))
            holder.weather_icon.setImageResource(R.drawable.snow);
        else if (this.weather_data.get(index).getCondition().contains("rain"))
            holder.weather_icon.setImageResource(R.drawable.rainy);
        else if (this.weather_data.get(index).getCondition().contains("wind"))
            holder.weather_icon.setImageResource(R.drawable.windy);
        else if (this.weather_data.get(index).getCondition().contains("sun"))
            if (this.weather_data.get(index).getCondition().contains("cloud"))
                holder.weather_icon.setImageResource(R.drawable.sun_cloud);
            else
                holder.weather_icon.setImageResource(R.drawable.sun);
        else if (this.weather_data.get(index).getCondition().contains("drizzle"))
            holder.weather_icon.setImageResource(R.drawable.drizzle);
        else
            holder.weather_icon.setImageResource(R.drawable.cloudy);

        index++;

    }

    @Override
    public int getItemCount() {
        return weather_data.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView date;
        TextView day;
        TextView min_temperature;
        TextView max_temperature;

        TextView weather_text;
        ImageView weather_icon;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.date);
            day = itemView.findViewById(R.id.day);
            max_temperature=itemView.findViewById(R.id.max_temp);
            min_temperature=itemView.findViewById(R.id.min_temp);
            weather_icon = itemView.findViewById(R.id.weather_icon);
            weather_text = itemView.findViewById(R.id.condition);
        }
    }
}
